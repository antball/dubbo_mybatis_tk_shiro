package com.juren.iservice;

public interface DemoService {

	String sayHello(String name);
	
}
