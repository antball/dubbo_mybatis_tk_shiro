package com.juren.test.dao;

import com.juren.test.model.TUser;
import tk.mybatis.mapper.common.Mapper;

public interface TUserMapper extends Mapper<TUser> {
}