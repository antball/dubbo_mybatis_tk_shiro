package com.juren.test.common;

/**
 * Created by DELL on 2017/7/8.
 */
public enum DynamicDataSourceGlobal {
    READ, WRITE;
}
